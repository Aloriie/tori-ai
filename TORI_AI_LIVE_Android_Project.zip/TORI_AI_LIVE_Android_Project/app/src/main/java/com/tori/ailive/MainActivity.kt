package com.tori.ailive

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var commentInput: EditText
    private var count = 0

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 15f, color: Int = Color.WHITE): TextView =
        TextView(this).apply {
            this.text = value
            textSize = size
            setTextColor(color)
        }
    private fun button(value: String, action: () -> Unit): Button =
        Button(this).apply { text = value; setOnClickListener { action() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundColor(Color.rgb(27, 19, 39))
        }
        root.addView(text("TORI AI LIVE", 25f).apply { setTypeface(null, 1) })
        root.addView(text("Android test build • mode layar terbagi", 12f, Color.LTGRAY))
        status = text("Status suara: menyiapkan…", 13f, Color.rgb(216, 180, 254))
        status.setPadding(0, dp(12), 0, dp(12))
        root.addView(status)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(49, 36, 65))
        }
        card.addView(text("UJI SUARA TORI", 16f).apply { setTypeface(null, 1) })
        card.addView(text("Tekan tombol untuk memastikan HP dapat membacakan jawaban.", 12f, Color.LTGRAY))
        card.addView(button("▶ TES SUARA") {
            speak("Halo! Aku Tori. Suara Tori siap menemani live kamu.")
        })
        root.addView(card)

        val gap = View(this).apply { minimumHeight = dp(12) }
        root.addView(gap)
        root.addView(text("SIMULASI KOMENTAR LIVE", 16f).apply { setTypeface(null, 1) })
        commentInput = EditText(this).apply {
            hint = "Contoh: Tori, kamu siapa?"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(245, 240, 250))
        }
        root.addView(commentInput)
        root.addView(button("KIRIM KOMENTAR UJI") {
            val incoming = commentInput.text.toString().trim()
            if (incoming.isNotEmpty()) {
                count++
                val reply = makeReply(incoming)
                log.text = "Komentar: $incoming\nTORI: $reply\n\n" + log.text
                commentInput.setText("")
                speak(reply)
            } else {
                Toast.makeText(this, "Isi komentar uji dulu.", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(text("LOG PERCAKAPAN", 14f).apply {
            setPadding(0, dp(10), 0, dp(5))
            setTypeface(null, 1)
        })
        log = text("Belum ada komentar. Masukkan komentar di atas untuk mencoba.", 13f, Color.rgb(235, 225, 245))
        val scroll = ScrollView(this).apply {
            addView(log)
            setBackgroundColor(Color.rgb(39, 29, 52))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("Catatan: ini aplikasi uji lokal. Belum membaca komentar TikTok otomatis dan belum terhubung Gemini/API.", 11f, Color.LTGRAY).apply {
            setPadding(0, dp(10), 0, 0)
        })
        setContentView(root)
    }

    private fun makeReply(input: String): String {
        val s = input.lowercase(Locale.ROOT)
        return when {
            s.contains("nama") || s.contains("siapa") -> "Aku Tori, asisten AI yang sedang menemani live ini!"
            s.contains("halo") || s.contains("hai") || s.contains("hello") -> "Halo juga! Terima kasih sudah mampir ke live."
            s.contains("apa kabar") -> "Aku baik dan siap ngobrol. Kamu bagaimana?"
            s.contains("terima kasih") || s.contains("makasih") -> "Sama-sama! Senang kamu hadir di sini."
            else -> "Wah, menarik! Terima kasih sudah berkomentar. Ada yang ingin kamu tanyakan lagi?"
        }
    }

    private fun speak(message: String) {
        if (ttsReady) {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "tori-${System.currentTimeMillis()}")
        } else {
            Toast.makeText(this, "Mesin suara belum siap.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("id", "ID"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            status.text = if (ttsReady) "Status suara: siap • Bahasa Indonesia" else "Status suara: bahasa Indonesia tidak tersedia"
        } else {
            status.text = "Status suara: gagal dimuat"
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
