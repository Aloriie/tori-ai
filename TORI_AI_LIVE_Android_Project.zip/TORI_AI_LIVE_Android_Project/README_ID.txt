TORI AI LIVE — proyek Android uji (bukan APK jadi)

ISI YANG SUDAH ADA
- Aplikasi Android sederhana dengan dashboard TORI.
- Tombol tes suara memakai Text-to-Speech bawaan Android.
- Kolom simulasi komentar dan jawaban otomatis sederhana.
- Cocok untuk menguji tampilan dan suara di HP Android.

YANG BELUM ADA
- Belum membaca komentar TikTok LIVE otomatis.
- Belum terhubung ke Gemini atau AI online.
- Belum ada avatar 3D / lip-sync.
- Belum mengirim komentar ke TikTok.
Jadi jangan gunakan ini sebagai host LIVE otomatis dulu.

CARA MEMBANGUN APK
1. Buka proyek ini di Android Studio pada komputer.
2. Tunggu Gradle selesai sinkronisasi.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.

CATATAN
- Proyek menggunakan Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35.
- Untuk build dibutuhkan Android SDK dan JDK yang sesuai.
- File ini adalah source project ZIP, bukan file APK yang sudah terpasang/ditandatangani.
